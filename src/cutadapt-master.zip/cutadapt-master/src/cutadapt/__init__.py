__all__ = ["__version__"]

from ._version import version as __version__
