.. include:: ../README.rst

=================
Table of contents
=================

.. toctree::
   :maxdepth: 2

   installation
   guide
   colorspace
   algorithms
   recipes
   ideas
   develop
   changes


..
   Indices and tables
   ==================
   
   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`

